$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Target = if ($args.Count -gt 0) { $args[0] } else { Join-Path (Split-Path -Parent $Root) 'bulletin_rasad_app' }

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw 'Flutter SDK پیدا نشد. ابتدا Flutter را نصب و به PATH اضافه کنید.'
}
if ((Test-Path $Target) -and (Get-ChildItem -Force $Target | Select-Object -First 1)) {
  throw "مسیر مقصد خالی نیست: $Target`nیک مسیر جدید انتخاب کنید."
}

flutter create --platforms=windows,android $Target
Copy-Item (Join-Path $Root 'lib/*') (Join-Path $Target 'lib') -Recurse -Force
New-Item -ItemType Directory -Force -Path (Join-Path $Target 'assets') | Out-Null
Copy-Item (Join-Path $Root 'assets/web') (Join-Path $Target 'assets') -Recurse -Force
Copy-Item (Join-Path $Root 'pubspec.yaml') $Target -Force
Copy-Item (Join-Path $Root 'README_FA.md') $Target -Force
Set-Location $Target
flutter pub get
Write-Host "پروژه آماده شد: $Target"
Write-Host 'اجرا در ویندوز: flutter run -d windows'
Write-Host 'ساخت APK: flutter build apk --release'
