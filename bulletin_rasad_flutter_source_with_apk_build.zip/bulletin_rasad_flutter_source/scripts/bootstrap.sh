#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-$ROOT/../bulletin_rasad_app}"
TARGET="$(mkdir -p "$(dirname "$TARGET")" && cd "$(dirname "$TARGET")" && pwd)/$(basename "$TARGET")"

if ! command -v flutter >/dev/null 2>&1; then
  echo "خطا: Flutter SDK پیدا نشد. ابتدا Flutter را نصب و به PATH اضافه کنید." >&2
  exit 1
fi
if [[ -e "$TARGET" ]] && [[ -n "$(find "$TARGET" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
  echo "خطا: مسیر مقصد خالی نیست: $TARGET" >&2
  echo "یک مسیر جدید انتخاب کنید: $0 /path/to/new-folder" >&2
  exit 1
fi

flutter create --platforms=windows,android "$TARGET"
cp -R "$ROOT/lib/." "$TARGET/lib/"
mkdir -p "$TARGET/assets"
rm -rf "$TARGET/assets/web"
cp -R "$ROOT/assets/web" "$TARGET/assets/"
cp "$ROOT/pubspec.yaml" "$TARGET/pubspec.yaml"
cp "$ROOT/README_FA.md" "$TARGET/README_FA.md"

cd "$TARGET"
flutter pub get
printf '\nپروژه آماده شد: %s\n' "$TARGET"
printf 'اجرا در ویندوز: flutter run -d windows\n'
printf 'ساخت APK: flutter build apk --release\n'
