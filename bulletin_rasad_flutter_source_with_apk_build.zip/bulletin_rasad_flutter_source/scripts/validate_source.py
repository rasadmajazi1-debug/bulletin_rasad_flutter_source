#!/usr/bin/env python3
"""Static smoke checks for the bundled offline HTML source."""
from html.parser import HTMLParser
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / 'assets' / 'web' / 'index.html'

class SourceInspector(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids = set()
        self.scripts = []
        self._in_script = False
        self._script_parts = []
        self.external_assets = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if attrs.get('id'):
            self.ids.add(attrs['id'])
        if tag == 'script':
            self._in_script = True
            self._script_parts = []
            if attrs.get('src'):
                self.external_assets.append(('script', attrs['src']))
        if tag == 'link' and attrs.get('href'):
            href = attrs['href']
            if href.startswith(('http://', 'https://', '//')):
                self.external_assets.append(('link', href))
    def handle_data(self, data):
        if self._in_script:
            self._script_parts.append(data)
    def handle_endtag(self, tag):
        if tag == 'script' and self._in_script:
            self.scripts.append(''.join(self._script_parts))
            self._in_script = False

if not HTML.is_file():
    sys.exit(f'FAIL: فایل HTML پیدا نشد: {HTML}')
source = HTML.read_text(encoding='utf-8')
parser = SourceInspector()
parser.feed(source)
parser.close()

required_ids = {'file', 'bkFile', 'bkExp', 'fontList', 'pv', 'frame'}
missing = sorted(required_ids - parser.ids)
if missing:
    sys.exit('FAIL: شناسه‌های ضروری یافت نشدند: ' + ', '.join(missing))
for marker in ('function saveFile(', 'indexedDB.open(', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'):
    if marker not in source:
        sys.exit('FAIL: قابلیت کلیدی در فایل دیده نشد: ' + marker)

print(f'PASS: فایل HTML موجود است ({HTML.stat().st_size:,} بایت)')
print(f'PASS: {len(parser.ids)} شناسه و {len(parser.scripts)} بلوک script بررسی شد')
if parser.external_assets:
    print('WARN: وابستگی‌های بیرونی یافت شد؛ برای اجرای کاملاً آفلاین بررسی کنید:')
    for kind, url in parser.external_assets:
        print(f'  - {kind}: {url}')
else:
    print('PASS: هیچ script/link بیرونی در HTML پیدا نشد')

node = shutil.which('node')
if not node:
    print('SKIP: Node.js نصب نیست؛ بررسی نحوی JavaScript انجام نشد')
    sys.exit(0)
inline_scripts = [s for s in parser.scripts if s.strip()]
checked = 0
for index, script in enumerate(inline_scripts, 1):
    # HTML may contain template-literal or browser-specific script fragments;
    # node --check validates syntax without executing browser APIs.
    result = subprocess.run([node, '--check', '-'], input=script, text=True, capture_output=True)
    if result.returncode:
        print(f'FAIL: خطای نحوی در بلوک script شماره {index}:')
        print(result.stderr.strip())
        sys.exit(result.returncode)
    checked += 1
print(f'PASS: نحو {checked} بلوک JavaScript با Node.js بررسی شد')
