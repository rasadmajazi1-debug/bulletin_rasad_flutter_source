import 'package:flutter/material.dart';

class UnsupportedPlatformView extends StatelessWidget {
  const UnsupportedPlatformView({super.key});

  @override
  Widget build(BuildContext context) => const Scaffold(
        body: Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text(
              'این نسخه برای ویندوز و اندروید آماده شده است.',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
}
