import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:webview_flutter_windows/webview_flutter_windows.dart';

class WindowsBulletinWebView extends StatefulWidget {
  const WindowsBulletinWebView({super.key});

  @override
  State<WindowsBulletinWebView> createState() => _WindowsBulletinWebViewState();
}

class _WindowsBulletinWebViewState extends State<WindowsBulletinWebView> {
  final WebviewController _controller = WebviewController();
  bool _ready = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      await _controller.initialize();
      await _controller.setPopupWindowPolicy(WebviewPopupWindowPolicy.deny);
      await _controller.setDefaultContextMenusEnabled(true);

      final html = await rootBundle.loadString('assets/web/index.html');
      final support = await getApplicationSupportDirectory();
      final webDir = Directory('${support.path}${Platform.pathSeparator}web');
      await webDir.create(recursive: true);
      final htmlFile = File('${webDir.path}${Platform.pathSeparator}index.html');
      await htmlFile.writeAsString(html, flush: true);
      await _controller.loadUrl(Uri.file(htmlFile.path).toString());
      if (mounted) setState(() => _ready = true);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.web_asset_off, size: 48, color: Colors.orangeAccent),
              const SizedBox(height: 12),
              const Text('اجرای محیط وب ویندوز ناموفق بود.', textAlign: TextAlign.center),
              const SizedBox(height: 8),
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              const Text('بررسی کنید WebView2 Runtime نصب باشد.', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(onPressed: () { setState(() { _error = null; _ready = false; }); _initialize(); }, icon: const Icon(Icons.refresh), label: const Text('تلاش دوباره')),
            ]),
          ),
        ),
      );
    }
    return Scaffold(
      body: SafeArea(
        child: _ready && _controller.value.isInitialized
            ? Webview(_controller)
            : const Center(child: CircularProgressIndicator()),
      ),
    );
  }
}
