import 'dart:io';

import 'package:flutter/material.dart';

import 'webview/android_webview.dart';
import 'webview/unsupported_view.dart';
import 'webview/windows_webview.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BulletinRasadApp());
}

class BulletinRasadApp extends StatelessWidget {
  const BulletinRasadApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF42C8F5);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ابزار ساخت بولتن رصد هفتگی',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
          surface: const Color(0xFF0B1224),
        ),
        scaffoldBackgroundColor: const Color(0xFF080D1B),
      ),
      home: const _AppHost(),
    );
  }
}

class _AppHost extends StatelessWidget {
  const _AppHost();

  @override
  Widget build(BuildContext context) {
    if (Platform.isAndroid) return const AndroidBulletinWebView();
    if (Platform.isWindows) return const WindowsBulletinWebView();
    return const UnsupportedPlatformView();
  }
}
